//  Use to navigate to All post page

function AllPost() {
  window.location.href = "../html/bloglist.html";
}
